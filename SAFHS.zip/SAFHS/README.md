# Safari Academy

**A HTML CSS Project**. Made with ♥ by web Ict Club <br>
live Preview: [Click Me](http://Safari Academy High School.com)

![](./readmeImg/banner.png)

